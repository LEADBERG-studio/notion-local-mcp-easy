import asyncio
import datetime
import fnmatch
import functools
import os
import re
import shutil
import urllib.request
from pathlib import Path

from mcp.server.fastmcp import FastMCP

API_TOKEN = os.environ.get("MCP_TOKEN", "").strip()
BASE_DIR = Path(os.environ.get("MCP_BASE_DIR", "D:/TG")).resolve()

mcp = FastMCP("My Local Tools (safe)", host="0.0.0.0", port=8000)

# --- Output guard ---
# Any tool result larger than this is truncated before it goes back to the
# agent. Unbounded outputs (big files, recursive listings, long command logs)
# are the usual cause of "vendorBadRequest" — they blow past the model's token
# limit or produce a payload the LLM vendor rejects. We also never return an
# empty string: empty content blocks make the Anthropic/OpenAI API 400.
MAX_OUTPUT_CHARS = 10_000


def _clip(text) -> str:
    if text is None:
        return "(no output)"
    text = str(text)
    if text == "":
        return "(empty result)"
    if len(text) > MAX_OUTPUT_CHARS:
        return (
            text[:MAX_OUTPUT_CHARS]
            + f"\n\n... [output truncated: {len(text):,} chars total, showing first "
            f"{MAX_OUTPUT_CHARS:,}. Use offset/limit or a narrower query to see more.]"
        )
    return text


def tool():
    """Like @tool() but clips every result through _clip()."""
    def deco(fn):
        @functools.wraps(fn)
        async def wrapper(*args, **kwargs):
            return _clip(await fn(*args, **kwargs))
        return mcp.tool()(wrapper)
    return deco


def _safe_path(path: str) -> Path:
    p = (BASE_DIR / path).resolve()
    if not str(p).startswith(str(BASE_DIR)):
        raise ValueError(f"Access denied: path outside BASE_DIR ({BASE_DIR})")
    return p


@tool()
async def run_command(command: str, timeout: int = 25) -> str:
    """Run a short shell command inside the allowed base directory. Timeout is 25 s by default (safe for Notion).
    For long-running commands (tests, build, linters) use run_command_bg instead."""
    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(BASE_DIR),
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return (
            f"exit code: {proc.returncode}\n"
            f"--- stdout ---\n{stdout.decode('utf-8', errors='replace')}\n"
            f"--- stderr ---\n{stderr.decode('utf-8', errors='replace')}"
        )
    except asyncio.TimeoutError:
        proc.kill()
        return f"Error: command exceeded {timeout}s. Use run_command_bg for long-running tasks."


@tool()
async def run_command_bg(command: str, output_file: str) -> str:
    """Run a long-running command in the background (tests, build, linters, installs).
    Output is written to output_file inside BASE_DIR. Returns immediately with the PID.
    Use read_file(output_file) after a delay to get the results.
    A line '=== DONE (exit N) ===' is appended when the command finishes."""
    out_path = _safe_path(output_file)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    async def _run():
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(f"=== STARTED: {command} ===\n")
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=str(BASE_DIR),
        )
        stdout, _ = await proc.communicate()
        with open(out_path, "a", encoding="utf-8") as f:
            f.write(stdout.decode("utf-8", errors="replace"))
            f.write(f"\n=== DONE (exit {proc.returncode}) ===\n")

    asyncio.create_task(_run())
    return f"Started in background (output → {out_path}). Call read_file('{output_file}') in ~10–30s to get results."


@tool()
async def write_file(path: str, content: str) -> str:
    """Create or overwrite a file inside the allowed base directory."""
    p = _safe_path(path)

    def _write():
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")

    await asyncio.to_thread(_write)
    return f"Wrote {len(content)} characters to {p}"


@tool()
async def append_file(path: str, content: str) -> str:
    """Append content to a file inside the allowed base directory."""
    p = _safe_path(path)

    def _append():
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a", encoding="utf-8") as f:
            f.write(content)

    await asyncio.to_thread(_append)
    return f"Appended {len(content)} characters to {p}"


@tool()
async def read_file(path: str, offset: int = 0, limit: int = 0) -> str:
    """Read a text file. Use offset/limit (in lines) to read large files in chunks."""
    p = _safe_path(path)

    def _read():
        data = p.read_bytes()
        # Null bytes in the first chunk = binary; reading it as text injects
        # junk into the conversation, which the LLM vendor can reject (400).
        if b"\x00" in data[:8192]:
            return None
        return data.decode("utf-8", errors="replace")

    text = await asyncio.to_thread(_read)
    if text is None:
        return f"(binary file, not shown as text): {p} — {p.stat().st_size:,} bytes"
    lines = text.splitlines(keepends=True)
    # Default to a bounded chunk instead of the whole file: an unbounded read
    # gets silently clipped by _clip, hiding the fact that more content exists.
    # Pass an explicit limit to read a larger range.
    DEFAULT_LIMIT = 400
    take = limit or DEFAULT_LIMIT
    total = len(lines)
    chunk = lines[offset:offset + take]
    more = offset + len(chunk)
    footer = (
        f"\n\n... [{total - more} more lines. Call read_file(offset={more}) to continue.]"
        if more < total else ""
    )
    return f"[lines {offset}–{more} of {total}]\n" + "".join(chunk) + footer


@tool()
async def list_dir(path: str = ".", recursive: bool = False) -> str:
    """List the contents of a directory. Set recursive=true to list all nested files."""
    def _list():
        p = _safe_path(path)
        if recursive:
            result = []
            for root, _, files in os.walk(p):
                rel = Path(root).relative_to(p)
                for f in sorted(files):
                    result.append(str(rel / f))
            return "\n".join(result)
        entries = []
        for name in sorted(os.listdir(p)):
            full = p / name
            size = full.stat().st_size if full.is_file() else 0
            kind = "DIR" if full.is_dir() else f"{size:,} B"
            entries.append(f"{kind:>12}  {name}")
        return "\n".join(entries)

    return await asyncio.to_thread(_list)


@tool()
async def file_info(path: str) -> str:
    """Get metadata about a file or directory: size, modification time, type."""
    def _info():
        p = _safe_path(path)
        if not p.exists():
            return f"Error: {p} does not exist."
        st = p.stat()
        mtime = datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        kind = "directory" if p.is_dir() else "file"
        return f"path: {p}\ntype: {kind}\nsize: {st.st_size:,} bytes\nmodified: {mtime}"

    return await asyncio.to_thread(_info)


@tool()
async def delete_file(path: str) -> str:
    """Delete a file or an empty directory inside the allowed base directory."""
    def _delete():
        p = _safe_path(path)
        if not p.exists():
            return f"Error: {p} does not exist."
        if p.is_dir():
            p.rmdir()
            return f"Deleted directory {p}"
        p.unlink()
        return f"Deleted file {p}"

    return await asyncio.to_thread(_delete)


@tool()
async def copy_file(src: str, dst: str) -> str:
    """Copy a file within the allowed base directory."""
    def _copy():
        s = _safe_path(src)
        d = _safe_path(dst)
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(s, d)
        return f"Copied {s} → {d}"

    return await asyncio.to_thread(_copy)


@tool()
async def move_file(src: str, dst: str) -> str:
    """Move or rename a file within the allowed base directory."""
    def _move():
        s = _safe_path(src)
        d = _safe_path(dst)
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
        return f"Moved {s} → {d}"

    return await asyncio.to_thread(_move)


@tool()
async def create_dir(path: str) -> str:
    """Create a directory inside the allowed base directory."""
    p = _safe_path(path)
    await asyncio.to_thread(p.mkdir, True, True)
    return f"Created directory {p}"


@tool()
async def edit_file(path: str, old_string: str, new_string: str, replace_all: bool = False) -> str:
    """Replace an exact string in a file. Use replace_all=true to replace every occurrence.
    The file must be read first to get the exact text. Fails if old_string is not found."""
    def _edit():
        p = _safe_path(path)
        content = p.read_text(encoding="utf-8")
        if old_string not in content:
            return f"Error: old_string not found in {p}. Read the file first and copy the text exactly."
        count = content.count(old_string) if replace_all else 1
        new_content = content.replace(old_string, new_string) if replace_all else content.replace(old_string, new_string, 1)
        p.write_text(new_content, encoding="utf-8")
        return f"Replaced {count} occurrence(s) in {p}"

    return await asyncio.to_thread(_edit)


@tool()
async def glob(pattern: str, path: str = ".") -> str:
    """Find files matching a glob pattern (e.g. **/*.py, src/**/*.ts)."""
    def _glob():
        base = _safe_path(path)
        matches = sorted(str(f.relative_to(base)) for f in base.glob(pattern) if f.is_file())
        return "\n".join(matches) if matches else "No files matched."

    return await asyncio.to_thread(_glob)


@tool()
async def grep(pattern: str, path: str = ".", file_glob: str = "*", regex: bool = False, max_results: int = 100) -> str:
    """Search for a pattern in files. Use regex=true for regular expressions."""
    def _grep():
        base = _safe_path(path)
        results = []
        for fpath in sorted(base.rglob(file_glob)):
            if not fpath.is_file():
                continue
            try:
                for i, line in enumerate(fpath.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                    hit = re.search(pattern, line) if regex else pattern.lower() in line.lower()
                    if hit:
                        results.append(f"{fpath.relative_to(base)}:{i}: {line.rstrip()}")
                        if len(results) >= max_results:
                            results.append(f"... (limit {max_results} reached)")
                            return "\n".join(results)
            except Exception:
                pass
        return "\n".join(results) if results else "No matches found."

    return await asyncio.to_thread(_grep)


@tool()
async def search_in_files(path: str, pattern: str, file_glob: str = "*", max_results: int = 100) -> str:
    """Search for a text pattern in files under a directory inside the allowed base directory."""
    def _search():
        base = _safe_path(path)
        results = []
        for root, _, files in os.walk(base):
            for fname in files:
                if not fnmatch.fnmatch(fname, file_glob):
                    continue
                fpath = Path(root) / fname
                try:
                    for i, line in enumerate(fpath.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                        if pattern.lower() in line.lower():
                            results.append(f"{fpath}:{i}: {line.rstrip()}")
                            if len(results) >= max_results:
                                results.append(f"... (limit {max_results} reached)")
                                return "\n".join(results)
                except Exception:
                    pass
        return "\n".join(results) if results else "No matches found."

    return await asyncio.to_thread(_search)


@tool()
async def http_get(url: str, timeout: int = 30) -> str:
    """Make an HTTP GET request and return the response body (up to 100 KB)."""
    def _get():
        req = urllib.request.Request(url, headers={"User-Agent": "MCP-local-tools/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(100_000).decode("utf-8", errors="replace")
            return f"status: {resp.status}\n\n{body}"

    return await asyncio.to_thread(_get)


@tool()
async def download_file(url: str, dest: str, timeout: int = 60) -> str:
    """Download a file from a URL to a local path inside the allowed base directory."""
    def _download():
        p = _safe_path(dest)
        p.parent.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(url, str(p))
        return f"Downloaded {url} → {p} ({p.stat().st_size:,} bytes)"

    return await asyncio.to_thread(_download)


# --- Auth middleware ---
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse


def extract_token(request) -> str:
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    if auth:
        return auth.strip()
    return request.headers.get("x-api-key", "").strip()


class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if API_TOKEN:
            incoming = extract_token(request)
            print(
                f"[auth] path={request.url.path} "
                f"extracted_len={len(incoming)} expected_len={len(API_TOKEN)} "
                f"match={incoming == API_TOKEN}"
            )
            if incoming != API_TOKEN:
                return JSONResponse(
                    {"error": "unauthorized", "hint": "token mismatch"},
                    status_code=401,
                )
        return await call_next(request)


if __name__ == "__main__":
    import uvicorn

    if API_TOKEN:
        print(f"[startup] MCP_TOKEN is set, length={len(API_TOKEN)}")
        print(f"[startup] BASE_DIR={BASE_DIR}")
    else:
        print("[startup] WARNING: MCP_TOKEN is empty — server is OPEN to anyone with the URL!")

    app = mcp.streamable_http_app()
    app.add_middleware(AuthMiddleware)
    uvicorn.run(app, host="0.0.0.0", port=8000)
